
		CamSeq01 Dataset,
  Cambridge-Toyota Labeled Objects in Video, 


 CamSeq01 is a groundtruth dataset that can be freely used only for research work in object recognition in video. 

If you intend to use this database, please cite the following paper:
   Julien Fauqueur, Gabriel Brostow, Roberto Cipolla, 
   "Assisted Video Object Labeling By Joint Tracking of Regions and Keypoints", 
   IEEE International Conference on Computer Vision (ICCV'2007) 
   Interactive Computer Vision Workshop. Rio de Janeiro, Brazil, October 2007

For more information, please visit: 
http://www.eng.cam.ac.uk/~jf330/CamSeq01/